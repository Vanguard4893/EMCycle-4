camonitor -#1 testErrors:AiInt32 \
              testErrors:LonginInt32 \
              testErrors:BiInt32 \
              testErrors:MbbiInt32 \
              testErrors:BiInt32 \
              testErrors:LonginUInt32D \
              testErrors:BiUInt32D \
              testErrors:MbbiUInt32D \
              testErrors:MbbiDUInt32D \
              testErrors:AiFloat64 \
              testErrors:SiOctet \
              testErrors:WfInOctet \
              testErrors:WfInt8 \
              testErrors:WfInt16 \
              testErrors:WfInt32 \
              testErrors:WfFloat32 \
              testErrors:WfFloat64 \
